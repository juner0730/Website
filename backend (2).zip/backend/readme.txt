firmRoot/
├─ app.py                   
├─ config.py              
├─ tracking/
│  ├─ __init__.py
│  ├─ tracker.py            
│  └─ geometry.py            
├─ vision/
│  ├─ __init__.py
│  ├─ color.py               
│  ├─ smoothing.py            
│  └─ jersey.py             
├─ events/
│  ├─ __init__.py
│  └─ segments.py           
│  ├─ video.py                
│  └─ logging_utils.py        
└─ predict.py                